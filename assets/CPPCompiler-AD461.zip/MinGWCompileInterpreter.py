from colorama import Style, Fore, init
import os
init()
#c++ -mwindows -static-libstdc++ -static-libgcc -Wl, -s -o compiled.exe *.cpp

print(f'{Fore.YELLOW}Welcome to MinGW Compiler interpreter\nCoded by {Fore.GREEN}ToxidWorm{Style.RESET_ALL}')
command = input('You really want to compile ".cpp" file (Y/N): ')
if command == 'Y':
	filename = input('File to compile: ')
	outputname = input('Output file name: ')
	try:
		os.system('c++ -mwindows -static-libstdc++ -static-libgcc -Wl, -s -o ' + outputname + ' ' + filename)
		print(f'{Fore.GREEN}Sucefully compiled your script!')
	except:
		print(f'{Fore.RED}Failed to compile code')